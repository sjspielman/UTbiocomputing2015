### Python 4 Homework


1. Write a script which parses file [hyphy\_output\_long.txt](../Lessons/python4_files/hyphy_output_long.txt) and outputs a csv file containing the following fields: site index, dN/dS, log-likelihood (Log(L)), and p-value. Be sure to include a header in the file.

2. Write a script which uses the function `re.sub` to convert the tab-delimited file [AbilAhuG\_uniprot\_blastx.txt](../Lessons/python4_files/AbilAhuG_uniprot_blastx.txt) to a csv file. 