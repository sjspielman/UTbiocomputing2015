def phylome_parser(infile):
	'''For parsing a phylomeDB ortholog file'''
	values = ("prot","ortholog","type","CS","trees","co-orthologs")
	with open(infile) as f:
		for line in f:
			line = line.strip().split("\t")
			line[-1] = line[-1].split(' ')
			assert len(line) == len(values)
			yield dict(zip(values,line))

def flatten(tuple_gen,group_col=0,value_col=1):
	'''
	(a,1)(a,2)(b,1) ---> (a,(1,2))(b,1)
	
	Infile must be sorted on group column.
	'''
	group = None
	values = []
	for tup in tuple_gen:
		assert len(tup) == 2, "Tuples must be length 2"
		assert group_col != value_col, "Group and Value columns must be different"
		curr_group = tup[group_col].strip()
		curr_value = tup[value_col].strip()
		if group != curr_group:
			if not group == None: # if not first iteration
				yield group, tuple(values) # yield last group
			group = curr_group
			values = []
		values.append(curr_value)
	yield group, tuple(values)
	
