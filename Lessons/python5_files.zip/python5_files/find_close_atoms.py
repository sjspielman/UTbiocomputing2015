#!/usr/bin/python
import sys
from Bio.PDB.PDBParser import PDBParser
parser = PDBParser()
from Bio.PDB.Vector import calc_angle
import math

import os
import csv
import re

def make_filelist(directory,file_ending):
	"""This function makes a list of files with a certain ending in a certain directory.
	"""
	files=os.listdir(directory)
	files_pdb=[]
	for file in files:
		if file.endswith(file_ending):
			files_pdb.append(file)
# 	print files
# 	print files_pdb
	return files_pdb
	
# make_filelist('.','.pdb')

def make_pairs(filelist):
	"""This function takes a list of files and finds ligand-structure pairs.
	"""
	ligands=[]
	structures=[]
	for item in filelist:
		if 'ligand' in item:
			ligands.append(item)
		elif 'nohet' in item:
			structures.append(item)
	ligands.sort()
	structures.sort()
	assert len(ligands) == len(structures), "length of lists are different"
	assert ligands[0][:4] == structures[0][:4], "dictionaries will not line up"
# 	print ligands, structures
	d={}
	for lig in ligands:
		for str in structures:
			if str[:4] == lig[:4]:
				d[str]=lig
	print d
	return d

def process_structure(structure,ligand,name):
	d={}
	l=[]
	str_parsed=parser.get_structure('structure',structure)
	lig_parsed=parser.get_structure('ligand', ligand)

	for l_model in lig_parsed:
		for l_chain in l_model:
			for l_residue in l_chain:
				for l_atom in l_residue:
					for s_model in str_parsed:
						for s_chain in s_model:
							for s_residue in s_chain:
								ref=s_residue["CA"]
								for s_atom in s_residue:
									distance=l_atom-s_atom
									bin_value= float(round(distance/0.5))*0.5
									if bin_value > 4.00 or bin_value < 0.001:
# 										print 'bin value %f is not within bins' %bin_value
										continue
									angle = calc_angle(l_atom.get_vector(),ref.get_vector(),s_atom.get_vector())
# 									print angle
									deg = math.degrees(angle)
									degrees=int(round(deg)+0.00001)
									l.append([name,distance,bin_value,degrees,s_residue.get_resname(), s_atom.get_name(), l_atom.get_name()])
	return l

def make_dictionary(file,columns):
	with open(file,'r') as f:
		reader=f.readlines()
	IDs={}
	refAtom=columns[1]
	valueAtom=columns[0]
	for row in reader:
		row=re.split('\s+',row)
# 		print row[refAtom],row[valueAtom]
		if row[refAtom] in IDs.keys():
			IDs[row[refAtom]].append(row[valueAtom])
		else:
			IDs[row[refAtom]]=[row[valueAtom]]
	print IDs
	return IDs

def print_file(data,id_list,output_file):
	"""Prints a csv file with wanted data.
	"""
	for line in data:
		ref_atom=line[6]
		for k in id_list:
			if ref_atom in id_list[k]:
				line.append(k)
# 	print data
	with open(output_file, 'wb') as f:
		f.write('Structure,Distance,Bin_Value,Degrees,Structure_Res,Structure_Atom,Ligand_Atom,Ligand_Atom_Code\n')
		csvwriter=csv.writer(f)
		for line in data:
			csvwriter.writerow(line)

def main():
	filelist=make_filelist('.','.pdb')
	pairs=make_pairs(filelist)
	for k in pairs:
		id_list=make_dictionary(pairs[k],[2,-2])
		distances=process_structure(k,pairs[k],k[:4])
		output=k[:4]+'_out.csv'
		print_file(distances,id_list,output)
		
main()

	
